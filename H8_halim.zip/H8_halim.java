/**
* This program will draw nth level Koch snowflake iterations 
* @author Halim Acosta
*/
import java.awt.*;
import javax.swing.*;
import java.util.*;
import java.math.*;
public class H8_halim{

private static final double ROTATOR = Math.sin(-Math.PI/3);
private static final double HALF = (1/2);
private static final int HEIGHT = 400;
private static final int WIDTH = 400;
private static final int XPOSITION = 150;
private static final int YPOSITION = 150;
private static final int X1 = 50;
private static final int Y1 = 250;
private static final int X2 = 350;
private static final int X3 = 200;
private static final int Y2 = 50;

    /**
    * This method will draw the nth level Koch snowFlake as dictated by the user
    * @param g Graphics the graphics that will do the drawing
    * @param level int the nth level of the snowflake to be drawn
    * @param frstPoint int the first point of the line segment
    * @param sndPoint int the end point of the line segment
    */
    public static void drawSnowFlake(Graphics g, int level,Point frstPoint, Point sndPoint){
        
        if(level == 0){
            g.drawLine(frstPoint.x,frstPoint.y,sndPoint.x,sndPoint.y);
        }else if(level >= 1){
            
            Point mid = new Point((sndPoint.x-frstPoint.x)/3,(sndPoint.y-frstPoint.y)/3);
            
            Point newOne = new Point((frstPoint.x+mid.x),(frstPoint.y+mid.y));
            Point newTwo = new Point((sndPoint.x-mid.x),(sndPoint.y-mid.y));
            
            double xbuff = newOne.x + (HALF*mid.x + mid.y*ROTATOR );
            double ybuff = newTwo.y + (HALF*mid.y - mid.x*ROTATOR );
            
            int testX = (newTwo.x-newOne.x)/2;
            int testY = (newTwo.y-newOne.y)/2;
            
            Point newThree = new Point((int)xbuff+testX,(int)ybuff-testY);
            Point testThree = new Point(testX,testY);
            
            drawSnowFlake(g,level-1,frstPoint,newOne);
            drawSnowFlake(g,level-1,newOne,newThree);
            drawSnowFlake(g,level-1,newThree,newTwo);
            drawSnowFlake(g,level-1,newTwo,sndPoint);

        }else{
            g.drawLine(frstPoint.x,frstPoint.y,sndPoint.x,sndPoint.y);
        }
    }
    /**
    * This method will stall the drawing panel so that it doesn't backup
    */
    private static void stall(){
        try{
            Thread.sleep(275);
        }catch(Exception e){
        }
    }
    /**
    * This method will create a window to be drawn in 
    * @param level int the level of the snowflake
    * @return window JFrame window that we draw in 
    */
    public static JFrame makeWindow(int level){
        JFrame window = new JFrame("Koch SnowFlake "+(level+1));
        window.setSize(WIDTH,HEIGHT);
        window.setLocation(XPOSITION,YPOSITION);
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setVisible(true);
        return window;
    }
    /**
    * This method will aggregate all the information and draw the snowFlake
    * @param args not used
    * 
    */
    public static void main(String[]args){
        Scanner console = new Scanner(System.in);
        
        System.out.println("Enter the level for the Koch SnowFlake:");
        int level = console.nextInt()-1;
                
        Point frstPoint = new Point(X1,Y1);
        Point sndPoint = new Point(X2,Y1);
        Point thrdPoint = new Point(X3,Y2); 
        
        JFrame window = makeWindow(level);
        
        Container pane = window.getContentPane();
        Graphics g = pane.getGraphics();
        
        stall();
        
        if(level < 0){
            g.drawLine(frstPoint.x,frstPoint.y,sndPoint.x,sndPoint.y);
        }else{
            drawSnowFlake(g,level,frstPoint,sndPoint);
            drawSnowFlake(g,level,sndPoint,thrdPoint);
            drawSnowFlake(g,level,thrdPoint,frstPoint);
        }
           
        
    }
}